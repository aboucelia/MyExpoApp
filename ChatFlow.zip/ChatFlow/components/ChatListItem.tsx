import React from "react";
import { View, StyleSheet, Pressable } from "react-native";
import { ThemedText } from "@/components/ThemedText";
import { Avatar } from "@/components/Avatar";
import { MessageStatus } from "@/components/MessageStatus";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/contexts/AuthContext";
import { Chat } from "@/types/chat";
import { formatChatTime } from "@/utils/dateUtils";
import { Spacing, Typography, WhatsAppColors } from "@/constants/theme";

interface ChatListItemProps {
  chat: Chat;
  onPress: () => void;
}

export function ChatListItem({ chat, onPress }: ChatListItemProps) {
  const { theme } = useTheme();
  const { user, getChatParticipants } = useAuth();
  const participants = getChatParticipants(chat);

  const displayName =
    chat.type === "group"
      ? chat.name || "Group"
      : participants[0]?.name || "Unknown";

  const avatarIndex =
    chat.type === "group"
      ? chat.avatar || 0
      : participants[0]?.avatar || 0;

  const isOnline =
    chat.type === "individual" && participants[0]?.isOnline;

  const isOwnMessage = chat.lastMessage?.senderId === user?.id;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.container,
        {
          backgroundColor: pressed
            ? theme.backgroundDefault
            : theme.backgroundRoot,
        },
      ]}
    >
      <Avatar
        name={displayName}
        avatarIndex={avatarIndex}
        size="medium"
        showOnline={chat.type === "individual"}
        isOnline={isOnline}
      />
      <View style={styles.content}>
        <View style={styles.topRow}>
          <ThemedText
            style={[styles.name, Typography.chatName]}
            numberOfLines={1}
          >
            {displayName}
          </ThemedText>
          {chat.lastMessage ? (
            <ThemedText
              style={[
                styles.time,
                Typography.timestamp,
                {
                  color:
                    chat.unreadCount > 0
                      ? WhatsAppColors.primary
                      : theme.textSecondary,
                },
              ]}
            >
              {formatChatTime(chat.lastMessage.timestamp)}
            </ThemedText>
          ) : null}
        </View>
        <View style={styles.bottomRow}>
          <View style={styles.messagePreview}>
            {isOwnMessage && chat.lastMessage ? (
              <View style={styles.statusIcon}>
                <MessageStatus status={chat.lastMessage.status} size={16} />
              </View>
            ) : null}
            <ThemedText
              style={[styles.lastMessage, { color: theme.textSecondary }]}
              numberOfLines={1}
            >
              {chat.lastMessage?.text || "No messages yet"}
            </ThemedText>
          </View>
          {chat.unreadCount > 0 ? (
            <View style={styles.badge}>
              <ThemedText style={styles.badgeText}>
                {chat.unreadCount > 99 ? "99+" : chat.unreadCount}
              </ThemedText>
            </View>
          ) : null}
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    height: Spacing.chatItemHeight,
  },
  content: {
    flex: 1,
    marginLeft: Spacing.md,
    justifyContent: "center",
  },
  topRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.xs,
  },
  name: {
    flex: 1,
    marginRight: Spacing.sm,
  },
  time: {},
  bottomRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  messagePreview: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
    marginRight: Spacing.sm,
  },
  statusIcon: {
    marginRight: Spacing.xs,
  },
  lastMessage: {
    flex: 1,
    fontSize: 14,
  },
  badge: {
    backgroundColor: WhatsAppColors.primary,
    borderRadius: 12,
    minWidth: 22,
    height: 22,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 6,
  },
  badgeText: {
    color: "#FFFFFF",
    fontSize: 12,
    fontWeight: "600",
  },
});
